/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sales;

import java.util.Scanner;

/**
 *
 * @author KeaBLeshomo
 */
public class Sales {

    public static void main(String[] args) {
        
        
              
        final int SALESPEOPLE = 5;
        
 int[] sales = new int[SALESPEOPLE];
 int sum;
 Scanner scan = new Scanner(System.in);
 for (int i=0; i<sales.length; i++)
     
 {
 System.out.print("Enter sales for salesperson " + i + ": ");
 sales[i] = scan.nextInt();
 }
 System.out.println("\nSalesperson Sales");
 System.out.println("--------------------");
 sum = 0;
 for (int i=0; i<sales.length; i++)
 {
 System.out.println(" " + i + " " + sales[i]);
 sum += sales[i];
 }
 System.out.println("\nTotal sales: " + sum);
 
    // Q1 calculates average
 int average = sum/SALESPEOPLE;
 System.out.println(average);
 
 
 //  promts for total sales and then finds max and min sales 
 int Sum = 0;
 int MaxSale = Integer.MIN_VALUE;
 int MinSale = Integer.MAX_VALUE;
 int MaxSalesPersonId = 0;
 int MinSalesPersonId = 0;
 
 
 
 
 for (int i = 0; i < sales.length; i++)
 {
    int CurrentSale = sales[i];
    sum += CurrentSale;
    
    if(CurrentSale > MaxSale)
    {    
     MinSale = CurrentSale;
     MinSalesPersonId = i+1;
    }
 }
 
 //  displays total, average,max and min sales
        System.out.println("SalesPerson sales");
        for(int i = 0; i< sales.length; i++) 
        {
            System.out.println("Salesperson" + (i + 1)+ ":$" + sales[i]);
        }
        System.out.println("Total sales: $" + sum);
        System.out.println("Average sale:$"+ average);
        System.out.println("SalesPerson" + MinSalesPersonId + "had the lowest sale with $"+ MinSale);
        
        // checks sales exceeding a certain amount
        System.out.println("Enter a value to see salespeople who exceeded it : ");
        int ThresHold = scan.nextInt();
        int numExceeded = 0;
        
        System.out.println(" SalesPeople who exceeded $" + ThresHold + ":");
        for(int i = 0; i< sales.length; i++)
        {
            if(sales[i]>ThresHold )
            {
                numExceeded++;
                System.out.println("SalesPerson" + (i+1)+ ":$" + sales[i]);
            }
        }
            
        
         System.out.println("Total number of SalesPeople whose sales exceeded $" + ThresHold + ":" + numExceeded);
    }
    
    
}
                
        
        
            
            
    
        
        
    
 


    
